-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 11, 2019 at 10:57 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbkoperasi`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_anggota`
--

CREATE TABLE `tb_anggota` (
  `id_anggota` int(11) NOT NULL,
  `nama_anggota` varchar(100) NOT NULL,
  `alamat_anggota` text NOT NULL,
  `tgl_lahir_anggota` date NOT NULL,
  `tempat_lahir_anggota` varchar(11) NOT NULL,
  `jenis_kelamin_anggota` varchar(15) NOT NULL,
  `status_anggota` varchar(14) NOT NULL,
  `no_telepo_anggota` varchar(15) NOT NULL,
  `keterangan_anggota` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_anggota`
--

INSERT INTO `tb_anggota` (`id_anggota`, `nama_anggota`, `alamat_anggota`, `tgl_lahir_anggota`, `tempat_lahir_anggota`, `jenis_kelamin_anggota`, `status_anggota`, `no_telepo_anggota`, `keterangan_anggota`) VALUES
(1, 'agung kuncoro', 'Tabanan', '2019-01-02', 'Denpasar', 'Pria', 'Baru', '81772887', 'Criminal Scum'),
(3, 'Putu Suherman', 'Jl. Kedondong	', '2019-01-10', 'Denpasar', 'Laki-Laki', 'Baru', '081772776552', 'Pengusaha at Wearnes'),
(4, 'Agung Hercules', 'Jl. Babel', '2019-01-11', 'Jakarta', 'Laki-Laki', 'Baru', '018772776333', 'Kuat, Binaragawan'),
(5, 'Mnemonic', 'Mars Auxutum', '2019-01-31', 'Impersectum', 'Perempuan', 'Baru', 'lilikikiaill', 'Alien'),
(6, 'Emmet', 'Gunung', '2019-01-11', 'China', 'Laki-Laki', 'Baru', '081882773887', 'Jual Senjata'),
(7, 'Carl Johnson', 'Groove Street', '2019-01-12', 'East Coast', 'Laki-Laki', 'Baru', '081772663776', 'Gangster'),
(8, 'Anthony Lee', 'Jl. Patimura', '2018-10-10', 'Magelang', 'Laki-Laki', 'Baru', '0817266667738', 'Pengusaha Bengkel');

-- --------------------------------------------------------

--
-- Table structure for table `tb_angsuran`
--

CREATE TABLE `tb_angsuran` (
  `id_angsuran` int(10) NOT NULL,
  `id_pinjaman` int(11) NOT NULL,
  `tgl_pembayaran` date NOT NULL,
  `angsuran_ke` int(11) NOT NULL,
  `besar_angsuran` int(11) NOT NULL,
  `keterangan_angsuran` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_angsuran`
--

INSERT INTO `tb_angsuran` (`id_angsuran`, `id_pinjaman`, `tgl_pembayaran`, `angsuran_ke`, `besar_angsuran`, `keterangan_angsuran`) VALUES
(3, 1, '2019-01-12', 1, 100000, 'ahaha'),
(4, 1, '2019-01-12', 0, 10000, 'adad'),
(5, 2, '2019-01-12', 0, 1999999901, 'lunas'),
(6, 1, '2019-01-12', 2, 1, 'Lunas'),
(7, 8, '2019-01-12', 1, 200000, '200rb per bulan'),
(8, 8, '2019-01-12', 2, 200000, '200rb / bln');

-- --------------------------------------------------------

--
-- Table structure for table `tb_angsuran_detail`
--

CREATE TABLE `tb_angsuran_detail` (
  `id_angsuran-detail` int(11) UNSIGNED NOT NULL,
  `id_angsuran` int(11) NOT NULL,
  `tgl-jatuh_tempo` date NOT NULL,
  `besar_angsuran_detail` varchar(200) NOT NULL,
  `keterangan_angsuran_detail` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_petugas`
--

CREATE TABLE `tb_petugas` (
  `Nama_petugas` varchar(100) NOT NULL,
  `Alamat_petugas` text NOT NULL,
  `No_telp_petugas` varchar(14) NOT NULL,
  `Tempat_lahir_petugas` varchar(100) NOT NULL,
  `tgl_lahir_petugas` date NOT NULL,
  `ket_petugas` text NOT NULL,
  `id_petugas` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_petugas`
--

INSERT INTO `tb_petugas` (`Nama_petugas`, `Alamat_petugas`, `No_telp_petugas`, `Tempat_lahir_petugas`, `tgl_lahir_petugas`, `ket_petugas`, `id_petugas`) VALUES
('Agus', 'Tabanan', '081288288388', 'Cengkareng', '2019-01-09', 'Aktif', 1),
('Pak Oka', 'Jl. Gunung', '081882887377', 'Tabanan', '2019-01-08', 'Aktif', 2),
('Made Lu Bu', 'Bangli', '082883882771', 'Tabanan', '2019-01-08', 'Aktif', 3),
('Eko Dan Guang', 'Jl. Riverwood, Province of Skyrim', '081882772887', 'Hammerfel', '2019-01-08', 'Aktif', 6),
('Herdi Kayan', 'Jl. Wearnes', '081777777777', 'Debnpasar', '2019-01-10', 'Nonaktif', 7),
('aaaaaaaaaaaaaaaaa', 'afffffff', '099999999999', 'ffff', '2019-01-10', 'Aktif', 8),
('assassin', 'prontera', '000000', 'morroc', '2019-01-11', 'Nonaktif', 9),
('crecentia', 'donglin forest', '0882888', 'Yggdrasil', '2019-01-01', 'Aktif', 10),
('Ayu Ningsih', 'Jl. Tukad Pakerisan', '081882773887', 'Gianyar', '2019-01-12', 'Aktif', 11);

-- --------------------------------------------------------

--
-- Table structure for table `tb_pinjaman`
--

CREATE TABLE `tb_pinjaman` (
  `id_pinjaman` int(10) NOT NULL,
  `id_pinajaman_katagori` int(11) NOT NULL,
  `id_anggota` int(11) NOT NULL,
  `besar_pinjaman` varchar(100) NOT NULL,
  `tgl_pengajuan_pinjaman` date NOT NULL,
  `tgl_acc_pinjaman` date NOT NULL,
  `tgl_pinjaman` date NOT NULL,
  `tgl_pelunasan` date NOT NULL,
  `keterangan_pinjaman` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_pinjaman`
--

INSERT INTO `tb_pinjaman` (`id_pinjaman`, `id_pinajaman_katagori`, `id_anggota`, `besar_pinjaman`, `tgl_pengajuan_pinjaman`, `tgl_acc_pinjaman`, `tgl_pinjaman`, `tgl_pelunasan`, `keterangan_pinjaman`) VALUES
(1, 1, 3, '0', '2019-01-11', '2019-01-12', '2019-01-12', '2019-01-12', 'Lunas'),
(2, 2, 5, '0', '2019-01-11', '2019-01-12', '2019-01-12', '2019-01-12', 'Lunas'),
(7, 3, 6, '20000000', '2019-01-12', '0000-00-00', '0000-00-00', '0000-00-00', 'Belum Acc'),
(8, 1, 8, '600000', '2019-01-12', '2019-01-12', '2019-01-12', '0000-00-00', 'Belum Lunas');

-- --------------------------------------------------------

--
-- Table structure for table `tb_pinjaman_katagori`
--

CREATE TABLE `tb_pinjaman_katagori` (
  `id_pinjaman_katagori` int(11) NOT NULL,
  `nama_pinjaman` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_pinjaman_katagori`
--

INSERT INTO `tb_pinjaman_katagori` (`id_pinjaman_katagori`, `nama_pinjaman`) VALUES
(1, 'Perorangan'),
(2, 'Perusahaan'),
(3, 'Pemerintahan'),
(4, 'Mafia'),
(5, 'Waralaba'),
(6, 'Desa');

-- --------------------------------------------------------

--
-- Table structure for table `tb_simpanan`
--

CREATE TABLE `tb_simpanan` (
  `id_simpanan` int(11) NOT NULL,
  `nama_simpanan` varchar(150) NOT NULL,
  `id_anggota` int(11) NOT NULL,
  `tgl_simpanan` date NOT NULL,
  `besar_simpanan` varchar(200) NOT NULL,
  `keterangan_simpanan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_simpanan`
--

INSERT INTO `tb_simpanan` (`id_simpanan`, `nama_simpanan`, `id_anggota`, `tgl_simpanan`, `besar_simpanan`, `keterangan_simpanan`) VALUES
(1, 'Simpanan Keras', 6, '2019-01-12', '1000000', 'Untuk membuka pengajuan pinjaman kepada koperasi'),
(2, 'Simpanan Awal', 1, '2019-01-12', '20000000', 'Sebagai dana wajib untuk koperasi'),
(3, 'Simpanan Hibah', 8, '2019-01-12', '1000000', 'Untuk menjadi member');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id_user` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `id_petugas` int(11) NOT NULL,
  `level` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id_user`, `username`, `password`, `id_petugas`, `level`) VALUES
(1, 'admin', 'admin', 1, 'Admin'),
(2, 'user', 'user', 2, 'User'),
(3, 'user2', 'user2', 6, 'User'),
(7, 'aa', 'aa', 3, 'User'),
(8, 'assassin', 'aaa', 9, 'User'),
(9, 'user3', 'user3', 8, 'User'),
(10, 'ayu123', 'ayu123', 11, 'User');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_anggota`
--
ALTER TABLE `tb_anggota`
  ADD PRIMARY KEY (`id_anggota`);

--
-- Indexes for table `tb_angsuran`
--
ALTER TABLE `tb_angsuran`
  ADD PRIMARY KEY (`id_angsuran`),
  ADD KEY `id_pinjaman` (`id_pinjaman`);

--
-- Indexes for table `tb_angsuran_detail`
--
ALTER TABLE `tb_angsuran_detail`
  ADD PRIMARY KEY (`id_angsuran-detail`),
  ADD KEY `id_angsuran` (`id_angsuran`);

--
-- Indexes for table `tb_petugas`
--
ALTER TABLE `tb_petugas`
  ADD PRIMARY KEY (`id_petugas`);

--
-- Indexes for table `tb_pinjaman`
--
ALTER TABLE `tb_pinjaman`
  ADD PRIMARY KEY (`id_pinjaman`),
  ADD KEY `id_pinajaman_katagori` (`id_pinajaman_katagori`),
  ADD KEY `id_anggota` (`id_anggota`);

--
-- Indexes for table `tb_pinjaman_katagori`
--
ALTER TABLE `tb_pinjaman_katagori`
  ADD PRIMARY KEY (`id_pinjaman_katagori`);

--
-- Indexes for table `tb_simpanan`
--
ALTER TABLE `tb_simpanan`
  ADD PRIMARY KEY (`id_simpanan`),
  ADD KEY `id_anggota` (`id_anggota`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id_user`),
  ADD KEY `id_petugas` (`id_petugas`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_anggota`
--
ALTER TABLE `tb_anggota`
  MODIFY `id_anggota` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tb_angsuran`
--
ALTER TABLE `tb_angsuran`
  MODIFY `id_angsuran` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tb_angsuran_detail`
--
ALTER TABLE `tb_angsuran_detail`
  MODIFY `id_angsuran-detail` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_petugas`
--
ALTER TABLE `tb_petugas`
  MODIFY `id_petugas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tb_pinjaman`
--
ALTER TABLE `tb_pinjaman`
  MODIFY `id_pinjaman` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tb_pinjaman_katagori`
--
ALTER TABLE `tb_pinjaman_katagori`
  MODIFY `id_pinjaman_katagori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tb_simpanan`
--
ALTER TABLE `tb_simpanan`
  MODIFY `id_simpanan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tb_angsuran`
--
ALTER TABLE `tb_angsuran`
  ADD CONSTRAINT `tb_angsuran_ibfk_1` FOREIGN KEY (`id_pinjaman`) REFERENCES `tb_pinjaman` (`id_pinjaman`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tb_angsuran_detail`
--
ALTER TABLE `tb_angsuran_detail`
  ADD CONSTRAINT `tb_angsuran_detail_ibfk_1` FOREIGN KEY (`id_angsuran`) REFERENCES `tb_angsuran` (`id_angsuran`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tb_pinjaman`
--
ALTER TABLE `tb_pinjaman`
  ADD CONSTRAINT `tb_pinjaman_ibfk_1` FOREIGN KEY (`id_pinajaman_katagori`) REFERENCES `tb_pinjaman_katagori` (`id_pinjaman_katagori`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tb_pinjaman_ibfk_2` FOREIGN KEY (`id_anggota`) REFERENCES `tb_anggota` (`id_anggota`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tb_simpanan`
--
ALTER TABLE `tb_simpanan`
  ADD CONSTRAINT `tb_simpanan_ibfk_1` FOREIGN KEY (`id_anggota`) REFERENCES `tb_anggota` (`id_anggota`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD CONSTRAINT `tb_user_ibfk_1` FOREIGN KEY (`id_petugas`) REFERENCES `tb_petugas` (`id_petugas`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
